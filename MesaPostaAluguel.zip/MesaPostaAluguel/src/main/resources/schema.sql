CREATE TABLE IF NOT EXISTS alugueis (
                                        id SERIAL PRIMARY KEY,
                                        nome_solicitante VARCHAR(100) NOT NULL,
    data_hora_solicitacao TIMESTAMP,
    nome_pedido VARCHAR(100) NOT NULL,
    data_reserva DATE NOT NULL,
    descricao TEXT,
    valor_aluguel NUMERIC(10,2) NOT NULL
    );
