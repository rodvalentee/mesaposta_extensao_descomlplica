package com.mesaposta.aluguel.controller;

import com.mesaposta.aluguel.entity.Aluguel;
import com.mesaposta.aluguel.service.AluguelService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.math.BigDecimal;
import java.time.LocalDate;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/alugueis")
@RequiredArgsConstructor
public class AluguelController {

    private final AluguelService aluguelService;

    @PostMapping
    public Mono<Aluguel> criar(@RequestBody @Valid Aluguel aluguel) {
        return aluguelService.salvar(aluguel);
    }

    @GetMapping
    public Flux<Aluguel> listarTodos() {
        return aluguelService.listarTodos();
    }

    @GetMapping("/{id}")
    public Mono<Aluguel> buscarPorId(@PathVariable Long id) {
        return aluguelService.buscarPorId(id);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> deletarPorId(@PathVariable Long id) {
        return aluguelService.deletarPorId(id);
    }
    @GetMapping("/futuros")
    public Flux<Aluguel> listarEntregasFuturas() {
        return aluguelService.listarFuturos();
    }

    @GetMapping("/passadas")
    public Flux<Aluguel> listarEntregasPassadas() {
        return aluguelService.listarPassadas();
    }

    @GetMapping("/relatorio/total")
    public Mono<BigDecimal> relatorioTotal() {
        return aluguelService.calcularTotalArrecadado();
    }

    @GetMapping("/filtro/nome")
    public Flux<Aluguel> buscarPorNome(@RequestParam String nome) {
        return aluguelService.buscarPorNome(nome);
    }

    @GetMapping("/filtro/intervalo")
    public Flux<Aluguel> buscarPorData(@RequestParam LocalDate inicio, @RequestParam LocalDate fim) {
        return aluguelService.buscarPorIntervalo(inicio, fim);
    }
}
