package com.mesaposta.aluguel.repository;

import com.mesaposta.aluguel.entity.Aluguel;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import org.springframework.data.r2dbc.repository.Query;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.LocalDate;

@Repository
public interface AluguelRepository extends ReactiveCrudRepository<Aluguel, Long> {

    Flux<Aluguel> findByDataReservaAfter(LocalDate data);

    Flux<Aluguel> findByDataReservaBefore(LocalDate data);

    @Query("SELECT SUM(valor_aluguel) FROM alugueis")
    Mono<BigDecimal> calcularTotalArrecadado();

    Flux<Aluguel> findByNomeSolicitanteContainingIgnoreCase(String nome);

    Flux<Aluguel> findByDataReservaBetween(LocalDate inicio, LocalDate fim);

}
