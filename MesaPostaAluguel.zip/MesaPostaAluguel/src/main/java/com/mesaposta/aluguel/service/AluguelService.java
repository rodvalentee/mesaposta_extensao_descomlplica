package com.mesaposta.aluguel.service;

import com.mesaposta.aluguel.entity.Aluguel;
import com.mesaposta.aluguel.repository.AluguelRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AluguelService {

    private final AluguelRepository aluguelRepository;

    public Mono<Aluguel> salvar(Aluguel aluguel) {
        aluguel.setDataHoraSolicitacao(LocalDateTime.now());
        return aluguelRepository.save(aluguel);
    }

    public Flux<Aluguel> listarTodos() {
        return aluguelRepository.findAll();
    }

    public Mono<Aluguel> buscarPorId(Long id) {
        return aluguelRepository.findById(id);
    }

    public Mono<Void> deletarPorId(Long id) {
        return aluguelRepository.deleteById(id);
    }

    public Flux<Aluguel> listarFuturos() {
        return aluguelRepository.findByDataReservaAfter(LocalDate.now());
    }

    public Flux<Aluguel> listarPassadas() {
        return aluguelRepository.findByDataReservaBefore(LocalDate.now());
    }

    public Mono<BigDecimal> calcularTotalArrecadado() {
        return aluguelRepository.calcularTotalArrecadado()
                .defaultIfEmpty(BigDecimal.ZERO); // se não houver nenhum registro
    }

    public Flux<Aluguel> buscarPorNome(String nome) {
        return aluguelRepository.findByNomeSolicitanteContainingIgnoreCase(nome);
    }

    public Flux<Aluguel> buscarPorIntervalo(LocalDate inicio, LocalDate fim) {
        return aluguelRepository.findByDataReservaBetween(inicio, fim);
    }


}
