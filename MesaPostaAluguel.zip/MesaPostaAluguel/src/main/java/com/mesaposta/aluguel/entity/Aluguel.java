package com.mesaposta.aluguel.entity;

import jakarta.validation.constraints.*;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Table("alugueis")
public class Aluguel {

    @Id
    private Long id;

    @NotBlank
    private String nomeSolicitante;

    private LocalDateTime dataHoraSolicitacao;

    @NotBlank
    private String nomePedido;

    @NotNull
    private LocalDate dataReserva;

    private String descricao;

    @NotNull
    @DecimalMin("0.0")
    private BigDecimal valorAluguel;
}
