// src/components/AluguelFilters.jsx
import React from 'react'
import { Search } from 'lucide-react'

export default function AluguelFilters({
                                           name, onNameChange,
                                           startDate, onStartDateChange,
                                           endDate, onEndDateChange,
                                           period, onPeriodChange
                                       }) {
    return (
        <div className="space-y-4">
            <div className="flex items-center space-x-2">
                <Search className="w-5 h-5 text-gray-400" />
                <input
                    type="text"
                    placeholder="Nome do cliente"
                    value={name}
                    onChange={e => onNameChange(e.target.value)}
                    className="flex-1 p-2 border border-gray-200 rounded-lg"
                />
            </div>
            <div className="flex space-x-2">
                <input
                    type="date"
                    value={startDate}
                    onChange={e => onStartDateChange(e.target.value)}
                    className="flex-1 p-2 border border-gray-200 rounded-lg"
                />
                <input
                    type="date"
                    value={endDate}
                    onChange={e => onEndDateChange(e.target.value)}
                    className="flex-1 p-2 border border-gray-200 rounded-lg"
                />
            </div>
            <select
                value={period}
                onChange={e => onPeriodChange(e.target.value)}
                className="w-full p-2 border border-gray-200 rounded-lg"
            >
                <option value="all">Todos</option>
                <option value="past">Passados</option>
                <option value="future">Futuros</option>
            </select>
        </div>
    )
}
