// src/components/AluguelForm.jsx
import React, { useState } from 'react'
import axios from 'axios'

export default function AluguelForm({ onSave }) {
    const [nomeSolicitante, setSolicitante] = useState('')
    const [nomePedido, setPedido] = useState('')
    const [dataReserva, setData] = useState('')
    const [valorAluguel, setValor] = useState('')

    const handleSubmit = async e => {
        e.preventDefault()
        await axios.post('http://localhost:8080/alugueis', {
            nomeSolicitante, nomePedido, dataReserva, valorAluguel
        })
        setSolicitante(''); setPedido(''); setData(''); setValor('')
        onSave()
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-gray-700">Solicitante</label>
                <input
                    value={nomeSolicitante}
                    onChange={e => setSolicitante(e.target.value)}
                    className="mt-1 w-full p-2 border border-gray-200 rounded-lg"
                />
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700">Pedido</label>
                <input
                    value={nomePedido}
                    onChange={e => setPedido(e.target.value)}
                    className="mt-1 w-full p-2 border border-gray-200 rounded-lg"
                />
            </div>
            <div className="flex space-x-4">
                <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700">Data de Reserva</label>
                    <input
                        type="date"
                        value={dataReserva}
                        onChange={e => setData(e.target.value)}
                        className="mt-1 w-full p-2 border border-gray-200 rounded-lg"
                    />
                </div>
                <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700">Valor (R$)</label>
                    <input
                        type="number"
                        value={valorAluguel}
                        onChange={e => setValor(e.target.value)}
                        className="mt-1 w-full p-2 border border-gray-200 rounded-lg"
                    />
                </div>
            </div>
            <button
                type="submit"
                className="mt-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
                Reservar
            </button>
        </form>
    )
}
