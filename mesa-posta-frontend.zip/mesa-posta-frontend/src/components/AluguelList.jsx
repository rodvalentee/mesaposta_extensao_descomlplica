import React from 'react'
import axios from 'axios'
import { Trash2 } from 'lucide-react'

export default function AluguelList({ alugueis, onDelete }) {
    console.log('▶ alugueis:', alugueis)
    return (
        <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
            <tr>
                {['ID','Solicitante','Pedido','Data Reserva','Valor (R$)','Ações']
                    .map(head => (
                        <th
                            key={head}
                            className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                        >
                            {head}
                        </th>
                    ))
                }
            </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-100">
            {alugueis.map((a, idx) => (
                <tr key={a.id} className={idx % 2 === 0 ? 'bg-purple-50' : ''}>
                    <td className="px-6 py-4 text-sm text-gray-700">{a.id}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{a.nomeSolicitante}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">{a.nomePedido}</td>
                    <td className="px-6 py-4 text-sm text-gray-700">
                        {new Date(a.dataReserva).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">
                        {Number(a.valorAluguel).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">
                        <button
                            onClick={() => axios.delete(`http://localhost:8080/alugueis/${a.id}`).then(onDelete)}
                            className="p-2 bg-red-50 rounded-lg hover:bg-red-100"
                        >
                            <Trash2 className="w-5 h-5 text-red-500" />
                        </button>
                    </td>
                </tr>
            ))}
            </tbody>
        </table>
    )
}
