// src/components/TotalArrecadado.jsx
import React, { useState, useEffect } from 'react'
import api from '../api.js'

export default function TotalArrecadado({ reload }) {
    const [total, setTotal] = useState(0)

    useEffect(() => {
        api.get('/alugueis/relatorio/total')
            .then(res => setTotal(res.data))
            .catch(console.error)
    }, [reload])    // ← agora recarrega sempre que `reload` mudar

    return (
        <span className="text-2xl font-bold">
      {Number(total).toLocaleString('pt-BR', {
          style: 'currency',
          currency: 'BRL'
      })}
    </span>
    )
}
