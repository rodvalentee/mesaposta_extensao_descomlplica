// src/App.jsx
import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { User } from 'lucide-react'
import AluguelForm from './components/AluguelForm'
import AluguelFilters from './components/AluguelFilters'
import TotalArrecadado from './components/TotalArrecadado'
import AluguelList from './components/AluguelList'

export default function App() {
    const [alugueis, setAlugueis] = useState([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)

    // filtros
    const [nameFilter, setNameFilter] = useState('')
    const [startDate, setStartDate] = useState('')
    const [endDate, setEndDate] = useState('')
    const [periodFilter, setPeriodFilter] = useState('all')

    const fetchAlugueis = async () => {
        try {
            setLoading(true)
            const { data } = await axios.get('http://localhost:8080/alugueis')
            setAlugueis(data)
        } catch {
            setError('Não foi possível carregar os aluguéis.')
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => { fetchAlugueis() }, [])

    const alugueisFiltrados = alugueis.filter(a => {
        const nome = (a.nomeSolicitante || '').toLowerCase()
        if (!nome.includes(nameFilter.toLowerCase())) return false

        const rentDate = new Date(a.dataReserva)
        if (startDate && rentDate < new Date(startDate)) return false
        if (endDate && rentDate > new Date(endDate)) return false

        if (periodFilter === 'past' && rentDate >= new Date()) return false
        if (periodFilter === 'future' && rentDate < new Date()) return false

        return true
    })

    return (
        <div className="min-h-screen bg-gray-100 p-6">
            <div className="max-w-6xl mx-auto bg-white rounded-2xl shadow-lg p-8 space-y-8">

                <h1 className="text-4xl font-extrabold text-gray-900 text-center">
                    Cadastro de Aluguel de Mesa Posta
                </h1>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-purple-50 p-6 rounded-xl">
                        <AluguelForm onSave={fetchAlugueis} />
                    </div>

                    <div className="space-y-6">
                        <div className="flex items-center bg-blue-50 p-6 rounded-xl shadow-sm">
                            <User className="w-8 h-8 text-blue-500 mr-3" />
                            <div>
                                <div className="text-sm font-medium text-gray-600">Total Arrecadado</div>
                                <div className="text-2xl font-bold text-gray-900">
                                    <TotalArrecadado reload={alugueis.length} />
                                </div>
                            </div>
                        </div>

                        <div className="bg-white p-6 rounded-xl shadow-sm space-y-4">
                            <AluguelFilters
                                name={nameFilter}
                                onNameChange={setNameFilter}
                                startDate={startDate}
                                onStartDateChange={setStartDate}
                                endDate={endDate}
                                onEndDateChange={setEndDate}
                                period={periodFilter}
                                onPeriodChange={setPeriodFilter}
                            />
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-xl shadow overflow-hidden">
                    {loading ? (
                        <p className="p-6 text-center">Carregando aluguéis...</p>
                    ) : error ? (
                        <p className="p-6 text-center text-red-500">{error}</p>
                    ) : (
                        <AluguelList alugueis={alugueisFiltrados} onDelete={fetchAlugueis} />
                    )}
                </div>
            </div>
        </div>
    )
}
